<?php
namespace Opencart\Admin\Controller\Extension\Fraudlabspro\Module;

class Login extends \Opencart\System\Engine\Controller {
    public function install(): void {
        $this->load->model('setting/event');

        // OpenCart 4 addEvent parameters: $code, $description, $trigger, $action, $status, $sort_order
        $this->model_setting_event->addEvent(
            'my_login_logger',                               // Event Code
            'Logs customer login attempts and IP addresses', // Description
            'catalog/controller/account/login|login/before', // Trigger (fires when login form posts)
            'extension/my_logger/event/login|beforeLogin',   // Action (Pipe '|' separator)
            true,                                           // Status (enabled)
            1                                               // Sort order
        );
    }

    public function uninstall(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode('my_login_logger');
    }
}