<?php
$_['heading_title'] = 'My Login Logger';